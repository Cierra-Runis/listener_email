<div align="center">
  <img id="listener_email" width="96" alt="listener_email" src="repository_icon/icon.svg">
  <p>『 listener_email - Let listener send email! 』</p>
  <a href='README_zh.md'>中文 Readme</a>
</div>

[📚 Introduction](#-Introduction)

[📦 How to use](#-How-to-use)

[⏳ Rate of progress](#-Rate-of-progress)

[📌 Precautions](#-Precautions)

[🧑‍💻 Contributor](#-Contributor)

[🔦 Declaration](#-Declaration)

---

# 📚 Introduction

Remind you of changes in your listener through email!

# 📦 How to use

Copy, paste then revise `README` file and the image in `repository_icon` folder

# ⏳ Rate-of-progress

Done, but it will revise if necessary

# 📌 Precautions

- Remember to revise the `id` and `alt` attribute in `<img>`
- Remember to revise the repository name in Contributor

# 🧑‍💻 Contributor

<a href="https://github.com/Cierra-Runis/listener_email/graphs/contributors">
  <img src="https://contrib.rocks/image?repo=Cierra-Runis/listener_email" />
</a>

# 🔦 Declaration

Mainly for personal use
